---
description: Cornerstone integration with view layer frameworks (e.g. React, Vue, Angular)
---

# Integration With React

#### React Integration Example
<iframe src="https://codesandbox.io/embed/xj172zjx5w?autoresize=1&hidenavigation=1" style="width:100%; height:500px; border:0; border-radius: 4px; overflow:hidden;" sandbox="allow-modals allow-forms allow-popups allow-scripts allow-same-origin"></iframe>
