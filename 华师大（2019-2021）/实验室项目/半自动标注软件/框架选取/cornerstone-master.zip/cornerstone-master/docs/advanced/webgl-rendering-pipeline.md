---
description: Cornerstone supports an optional WebGL rendering pipeline for increased performance.
---

# WebGL Rendering Pipeline

> Cornerstone supports an optional WebGL rendering pipeline for increased performance.
