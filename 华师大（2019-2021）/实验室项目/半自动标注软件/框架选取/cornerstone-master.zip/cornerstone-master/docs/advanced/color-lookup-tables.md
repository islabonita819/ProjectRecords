---
description: Developers can define their own Color Lookup Tables for displaying grayscale images with false color maps.
---

# Color Lookup Tables

> Developers can define their own **Color Lookup Tables** for displaying grayscale images with false color maps.
