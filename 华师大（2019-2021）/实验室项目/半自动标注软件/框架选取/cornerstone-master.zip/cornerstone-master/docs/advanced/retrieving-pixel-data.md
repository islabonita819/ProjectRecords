---
description: Cornerstone supports retrieval of stored and transformed pixels from Images.
---

# Retrieving Pixel Data

> Cornerstone supports retrieval of stored and transformed pixels from Images.

* [getPixels](../api.md#getpixels)
* [getStoredPixels](../api.md#getstoredpixels)
