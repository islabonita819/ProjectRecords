---
description: Cornerstone supports both Value of Interest (VOI) and Modality Lookup Tables (LUTs).
---

# Modality LUT and VOI LUT

> Cornerstone supports both Value of Interest (VOI) and Modality Lookup Tables.

Lookup tables define transformations from stored pixel values to presentation pixel values.

Cornerstone supports linear and non-linear VOI LUTs.
