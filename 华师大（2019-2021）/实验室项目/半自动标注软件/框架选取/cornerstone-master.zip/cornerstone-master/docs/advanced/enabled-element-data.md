---
description: Cornerstone supports storing and retrieving arbitrary Enabled Element Data within the HTML data- fields of an Element.
---

# Enabled Element Data

> Cornerstone supports storing and retrieving arbitrary **Enabled Element Data**.
