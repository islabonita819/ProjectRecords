// For authoring Nightwatch tests, see
// http://nightwatchjs.org/guide#usage

module.exports = {
  'default e2e tests': function (browser) {
    // automatically uses dev Server port from /config.index.js
    // default: http://localhost:8080
    // see nightwatch.conf.js
    const devServer = browser.globals.devServerURL

    browser
      .url(devServer)
      .waitForElementVisible('#app', 5000)
      .assert.elementPresent('.legend')
      .assert.containsText('.legend', 'Powered by dwv')
      .assert.elementCount('.layerContainer', 1)
      .assert.elementCount('.imageLayer', 1)
      .end()
  }
}
